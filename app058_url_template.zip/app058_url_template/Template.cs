﻿using System;
using System.Collections.Generic;
public delegate bool validateProc(string value);
class Template
{
    private string _pattern = "";
    List<Pattern> _list = new List<Pattern>();
    Dictionary<string, validateProc> _fieldsValidators;

    public Template(string pattern, Dictionary<string, validateProc> fieldsValidators)
    {
        //проверка pattern
        if (string.IsNullOrEmpty(pattern)) { throw new Exception("Шаблон пуст"); }
        _pattern = pattern.Trim();
        //положение каретки на открывающей скобе
        int caret = 0;
        //начало литерала
        int startLiteral = 0;
        //конец литерала
        int startFiller = 0;

        while (caret > -1)
        {
            if (startLiteral + 1 > pattern.Length) { break; }
            caret = _pattern.IndexOf('{', caret);
            if (caret > 0)
            {
                startFiller = caret + 1;
                try { _list.Add(new Literal(_pattern.Substring(startLiteral, caret - startLiteral))); } catch (Exception e) { throw new Exception(e.Message); }
            }
            else if (caret < 0 && startLiteral > 0)
            {
                try { _list.Add(new Literal(_pattern.Substring(startLiteral, _pattern.Length - startLiteral))); } catch (Exception e) { throw new Exception(e.Message); }
            }
            else
            {
                try { _list.Add(new Literal(_pattern)); } catch (Exception e) { throw new Exception(e.Message); }
                break;
            }

            try { caret = _pattern.IndexOf('}', caret); }
            catch (Exception) { continue; }
            if (caret > 0)
            {
                try
                {
                    Filler newFiller = new Filler(_pattern.Substring(startFiller, caret - startFiller));
                    int index = 1;

                    while (index < _list.Count)
                    {
                        if (newFiller.Name == _list[index].Name) { throw new Exception("Имя заполнителя не может повторяться"); }
                        index++;
                    }
                    if (!fieldsValidators.ContainsKey(newFiller.Name)) { throw new Exception(""); }
                    if (fieldsValidators[newFiller.Name] == null) { }

                    _list.Add(newFiller);
                }
                catch (Exception e) { throw new Exception(e.Message); }

                startLiteral = caret + 1;
            }
            else { throw new Exception("Ошибка "); }

            _fieldsValidators = fieldsValidators;
        }
    }

    public bool Match(Uri incomingURL)
    {
        //путь пришедшего запроса
        string incomingUrlLocalPath = incomingURL.LocalPath;
        string literalFromUrl = "";
        int patternLiteralLength = 0;

        int index = 0;
        while (index < _list.Count)
        {
            //длина литерала шаблона
            patternLiteralLength = _list[index].Name.Length;

            //поиск нулевого символа литерала шаблона в пути запроса
            int caret = incomingUrlLocalPath.IndexOf(_list[index].Name[0], 0);
            if (caret < 0) { return false; }
            
            //обрезаю строку пути запроса по длине литерала шаблона
            try { literalFromUrl = incomingUrlLocalPath.Substring(caret, patternLiteralLength); }
            catch (Exception) { return false; }

            //записываю в переменную литерал шаблона
            string literalName = _list[index].Name;

            //проверяю совпадают ли символы в пути запроса и литерале шаблона
            if (literalName[0] == literalFromUrl[0])
            {
                //внутренний индекс цикла
                int innerIndex = 1;
                while (innerIndex < literalName.Length)
                {
                    //если не совпадают возвращаю false
                    if (literalName[innerIndex] != literalFromUrl[innerIndex]) { return false; }
                    innerIndex++;
                }
            }
            else { return false; }


            //увеличиваю индекс до следующего литерала
            index += 2;
        }
        return true;
    }

    public string Pattern { get { return _pattern; } }

    public static bool validate_workID(string value)
    {
        //workID - целое число, длина 9 знаков, не может начинаться с нуля
        if (string.IsNullOrEmpty(value) || value.Length != 9 || value[0] == 0) { return false; }
        try { int number = int.Parse(value); } catch (Exception) { return false; }
        return true;
    }
    public static bool validate_filePath(string value)
    {
        //filePath - только буквы, цифры, _, - / . (без пар, символы не могут быть рядом)
        if (string.IsNullOrEmpty(value)) { return false; }
        string _value = value.Trim().ToLower();
        string allSigns = "abcdefghijklmnopqrstuvwxyz0123456789/-_=.";
        char symbol = ' ';
        char nextSymbol = ' ';
        int index = 0;
        while (index < _value.Length)
        {
            symbol = _value[index];
            if (!allSigns.Contains(symbol.ToString())) { return false; }
            if (index + 1 < _value.Length)
            {
                nextSymbol = _value[index + 1];
                if (!char.IsLetterOrDigit(symbol))
                {
                    if ("/-_=.".Contains(nextSymbol.ToString())) { return false; }
                }
            }
            index++;
        }
        return true;
    }
    public static bool validate_postID(string value)
    {
        //postID - только число, 5 знаков, не может начинаться с нуля
        if (string.IsNullOrEmpty(value) || value.Length < 5 || value.Length > 5 || value[0] == 0) { return false; }
        try { int number = int.Parse(value); } catch (Exception) { return false; }
        return true;
    }
    public static bool validate_userID(string value)
    {
        // userID - целом числом, длина 9 знаков, всегда начинается на 1
        if (string.IsNullOrEmpty(value) || value.Length != 9 || value[0] != 1) { return false; }
        try { int number = int.Parse(value); } catch (Exception) { return false; }
        return true;
    }
    public static bool validate_promoID(string value)
    //promoID - только число, 9 знков, не может начинаться с нуля
    {
        if (string.IsNullOrEmpty(value) || value.Length != 9 || value[0] == 0) { return false; }
        try { int number = int.Parse(value); } catch (Exception) { return false; }
        return true;
    }
    public static bool validate_year(string value)
    //year - только число, 4 знака, не больше текущего года
    {
        int number;
        if (string.IsNullOrEmpty(value) || value.Length != 4) { return false; }
        try { number = int.Parse(value); } catch (Exception) { return false; }
        if (number > DateTime.Now.Year) { return false; }
        return true;
    }
    public static bool validate_month(string value)
    // month - только число, 2 знака (от 01 до 12)
    {
        int number;
        if (string.IsNullOrEmpty(value) || value.Length != 2) { return false; }
        try { number = int.Parse(value); } catch (Exception) { return false; }
        if (number < 1 || number > 12) { return false; }
        return true;
    }
    public static bool validate_tagName(string value)
    {
        //tagName - только буквы и знак - (не может быть в начале, без пары), длина не более 150 знаков
        string _value = value.Trim().ToLower();
        string allSigns = "abcdefghijklmnopqrstuvwxyz-";
        char symbol = ' ';
        char nextSymbol = ' ';
        int index = 0;
        if (string.IsNullOrEmpty(value) || value.Length > 150 || !allSigns.Contains(symbol.ToString()) || _value[0] == '-') { return false; }

        while (index < _value.Length)
        {
            symbol = _value[index];
            if (index + 1 < _value.Length)
            {
                nextSymbol = _value[index + 1];
                if (!char.IsLetterOrDigit(symbol))
                {
                    if ("-".Contains(nextSymbol.ToString())) { return false; }
                }
            }
            index++;
        }
        return true;
    }
    public static bool validate_extension(string value)
    {
        //extension->только буквы, от 3 до 5 символов
        string _value = value.ToLower().Trim();
        if (string.IsNullOrEmpty(value) || _value.Length < 3 || _value.Length > 5) { return false; }
        foreach (char letter in _value) { if (!char.IsLetter(letter)) { return false; } }
        return true;
    }
    //imageFileName - только буквы, цифры, _, - / . (без пар, символы не могут быть рядом)
    public static bool validate_imageFileName(string value)
    {
        int index = 0;
        char symbol = ' ';
        if (string.IsNullOrEmpty(value)) { return false; }
        value.ToLower().Trim();
        string allSymbols = "abcdefghijklmnopqrstuvwxyz0123456789_-/.";
        if (!allSymbols.Contains(value)) { return false; }
        while (index < value.Length)
        {
            symbol = value[index];
            if (index + 1 < value.Length)
            {
                if ("_-/.".Contains(symbol.ToString()) && "_-/.".Contains(value[index + 1].ToString())) { { return false; } }
                index++;
            }
        }
        return true;
    }
    public static bool validate_scriptPath(string value)
    {
        //scriptPath - только буквы, цифры, _, - / . (без пар, символы не могут быть рядом)
        int index = 0;
        char symbol = ' ';
        if (string.IsNullOrEmpty(value)) { return false; }
        value.ToLower().Trim();
        string allSymbols = "abcdefghijklmnopqrstuvwxyz0123456789_-/.";
        if (!allSymbols.Contains(value)) { return false; }
        while (index < value.Length)
        {
            symbol = value[index];
            if (index + 1 < value.Length)
            {
                if ("_-/.".Contains(symbol.ToString()) && "_-/.".Contains(value[index + 1].ToString())) { { return false; } }
                index++;
            }
        }
        return true;
    }
    public static bool validate_chatID(string value)
    {
        // chatID - только число, длина 18 знаков, не может начинаться с нуля
        if (string.IsNullOrEmpty(value) || value.Length < 18 || value.Length > 18 || value[0] == 0) { return false; }
        try { int number = int.Parse(value); } catch (Exception) { return false; };
        return true;
    }
    public static bool validate_view(string value)
    {
        //view - только число 1 или 2
        if (string.IsNullOrEmpty(value) || value.Length != 1 || value[0] != 1 || value[0] != 2) { return false; }
        return true;
    }
    public static bool validate_sort(string value)
    {
        //sort - только "az" или "za"
        string az = "az";
        string za = "za";
        if (az.Equals(value) || za.Equals(value)) { return true; }
        else { return false; }
    }
    public static bool validate_date(string value)
    {
        //date - в формате YYYY/MM/DD
        int year, month, day;
        if (string.IsNullOrEmpty(value) || value.Length < 10 || value.Length > 10 || value[4] != '/' || value[7] != '/') { return false; }
        DateTime date = new DateTime();
        try
        {
            year = int.Parse(value.Substring(0, 4));
            month = int.Parse(value.Substring(5, 2));
            day = int.Parse(value.Substring(8, 2));
            date = new DateTime(year, month, day);
        }
        catch (Exception) { return false; }
        if (date > DateTime.Now) { return false; }
        return true;
    }

}

//обработчики
//делегаты

/*
    /main.html
    /about.html
    /portfolio.html
    /portfolio/work-   {workID}   .html
    /blog.html
    /blog/post/{postID}.html
    /{filePath}.txt
    /user/avatar/{userID}    .jpg
    /promo-   {promoID}   .html
    /blog/year-   {year}   .html
    /blog/year-   {year}   /month-   {month}   /list.html
    /blog/tag-   {tagName}   .html
    /orders.html
    /orders/   {date}   .html?sort=   {sort}   &view=   {view}
    /chat/   {chatID}     /user-1-   {user1ID}       /user-2-   {user2ID}   .html
    /app/   {scriptPath}   .js
    /app/style/   {scriptPath}   .css
    /app/style/images/    {imageFileName}    .    {extension}
   
 */

/* Правила для заполнителей:
 * 
 workID - целое число, длина 9 знаков, не может начинаться с нуля 
 filePath - только буквы, цифры, _, - / . (без пар, символы не могут быть рядом)
 postID - только число, 5 знаков, не может начинаться с нуля
 userID - целом числом, длина 9 знаков, всегда начинается на 1
 promoID - только число, 9 знков, не может начинаться с нуля
 year - только число, 4 знака, не больше текущего года
 month - только число, 2 знака (от 01 до 12)
 tagName - только буквы и знак - (не может быть в начале, без пары), длина не более 150 знаков

 date - в формате YYYY/MM/DD
 sort - только "az" или "za"
 view - только число 1 или 2
 chatID - только число, длина 18 знаков, не может начинаться с нуля
 scriptPath -> аналогично filePath
 imageFileName -> filePath
 extension -> только буквы, от 3 до 5 символов

 */

